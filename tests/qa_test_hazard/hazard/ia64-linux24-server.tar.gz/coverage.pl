#!/usr/local/bin/perl
# WHATSTRING
# Usage: perl coverage.pl <rawLogFile

$maxdid  = 0;
$cursid  = -1;
$tests[0] = "diskraw";
$tests[1] = "diskfs";
$tests[2] = "diskall";

while (<STDIN>) {
  chomp($_);
  ($gpid,$tm,$x) = split(/\./,$_);
  if (/:start =/) {
    ($lvl,$y)         = split(/:/,$x);
    ($sa,$sb,$sc,$sd) = split(/ = /,$y);
    $start[$gpid] = $tm;
    # printf "gpid=$gpid, st=$start[$gpid]\n";
  }
  elsif (/:stop: /) {
    $delta = $tm - $start[$gpid];
    $start[$gpid] = 0;
    # printf "gpid=$gpid, delta=$delta ($tids[$gpid],$dids[$gpid],$sids[$gpid])\n";
    $key = "$dids[$gpid]"."_"."$sids[$gpid]";
    if ($tids[$gpid] == 0)    { $rawMat{"$key"} += $delta; }
    elsif ($tids[$gpid] == 1) { $filMat{"$key"} += $delta; }
    elsif ($tids[$gpid] == 2) { $allMat{"$key"} += $delta; }
  }
  elsif (/:PROCESS test=disk/) {	# logged during SCAN phase
    $vars = substr($x,index($x," ")+1,1024);
    # hash the process attributes
    @list = split(/;/,$vars);
    %attr = map(split(/=/,$_),@list);
    # track gpid, testname, did, and hostname
    $gpid        = $attr{"gpid"};
    if ($attr{"test"} eq $tests[0])    { $tids[$gpid] = 0; }
    elsif ($attr{"test"} eq $tests[1]) { $tids[$gpid] = 1; }
    elsif ($attr{"test"} eq $tests[2]) { $tids[$gpid] = 2; }
    $dids[$gpid] = $attr{"did"};
    $sids[$gpid] = $cursid;
    if ($maxdid < $dids[$gpid]) { $maxdid = $dids[$gpid]; }
    # printf "gpid=$gpid, test=$attr{\"test\"}, tid=$tids[$gpid], did=$dids[$gpid], sid=$sids[$gpid], ip=$ips[$sids[$gpid]]\n";
  }
  elsif (/:SCAN type=system/) {		# logged during SCAN phase
    $vars = substr($x,index($x," ")+1,1024);
    # hash the (system) scan attributes
    @list = split(/;/,$vars);
    %attr = map(split(/=/,$_),@list);
    # remember the hostname
    $ip = $attr{"ip"};
    $cursid++;
    # printf "ip=$ip, sid=$cursid\n";
  }
  elsif (/:PROCESS test=client/) {	# logged between INIT and SCAN phases
    $vars = substr($x,index($x," ")+1,1024);
    # hash the process attributes
    @list = split(/;/,$vars);
    %attr = map(split(/=/,$_),@list);
    # remember the sid
    $sid       = $attr{"sid"};
    $ips[$sid] = $ip;
    # printf "ip=$ips[$sid], sid=$sid ($ips[0])\n";
  }
  elsif (/:SCAN ip=/) {			# logged between INIT and SCAN phases
    $vars = substr($x,index($x," ")+1,1024);
    # hash the process attributes
    @list = split(/;/,$vars);
    %attr = map(split(/=/,$_),@list);
    # remember the hostname
    $ip = $attr{"ip"};
    # printf "ip=$ip\n";
  }
}
# printf "$#ips $#tids $maxdid\n";
#
# print header
printf "Diskraw Test Coverage (seconds of testing)\n";
printf "--did-- ";
for $i (0..$#ips) {
  printf("%8s ",$ips[$i]);
}
printf "\n";
# print rows
for $j (0..$maxdid) {	# iterate over set of did's
  printf("%7d ", $j);
  for $i (0..$#ips) {	# iterate over set of sid's
    $key = "$j"."_"."$i";
    printf("%8d ", $rawMat{"$key"});
  }
  printf "\n";
}
printf "\n\n";		# space between tables
#
# print header
printf "Diskfs Test Coverage (seconds of testing)\n";
printf "--did-- ";
for $i (0..$#ips) {
  printf("%8s ",$ips[$i]);
}
printf "\n";
# print rows
for $j (0..$maxdid) {	# iterate over set of did's
  printf("%7d ", $j);
  for $i (0..$#ips) {	# iterate over set of sid's
    $key = "$j"."_"."$i";
    printf("%8d ", $filMat{"$key"});
  }
  printf "\n";
}
printf "\n\n";          # space between tables
#
# print header
printf "Diskall Test Coverage (seconds of testing)\n";
printf "--did-- ";
for $i (0..$#ips) {
  printf("%8s ",$ips[$i]);
}
printf "\n";
# print rows
for $j (0..$maxdid) {	# iterate over set of did's
  printf("%7d ", $j);
  for $i (0..$#ips) {	# iterate over set of sid's
    $key = "$j"."_"."$i";
    printf("%8d ", $allMat{"$key"});
  }
  printf "\n";
}
