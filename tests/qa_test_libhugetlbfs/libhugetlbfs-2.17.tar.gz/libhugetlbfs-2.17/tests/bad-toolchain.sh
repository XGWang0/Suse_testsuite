#! /bin/sh

echo "Bad toolchain: can't build this testcase"

exit 1
