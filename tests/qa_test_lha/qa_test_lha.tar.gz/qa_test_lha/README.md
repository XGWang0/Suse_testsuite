===
lha
===

Testcases
=========

**commands can be used with or without "-", options only with "-"**

* Create an archive
  - create
  lha c archive_file.lzh files or directories.
  - create or append
  lha a archive_file.lzh files or directories.
  - create with compression method (lh5 is default)
  lha -co6-7 archive_file.lzh files or directories.
  - create and move files to archive(delete on disk)
  lha -ad archive_file.lzh files or directories.
  - create with excluded  pattern
  lha c -x=exculded archive_file.lzh files or directories.

* Update archive
  - update
  lha u archive_file.lzh files or directories.
  - update with append
  lha u -a archive_file.lzh files or directories.
  - move files to the archive (like -ad)
  lha m archive_file.lzh files or directories.
  - delete files from archive
  lha d archive_file.lzh files


* Extract the archive
  - extract
  lha x archive_file.lzh [specific files]
  - extract with force - override without asking
  lha -xf archive_file.lzh [specific files]
  - extract to specific dir
  lha x -w=/tmp/dir archive_file.lzh [specific files]

* List the archive
  - list
  lha l archive_file.lzh
  - list
  lha archive_file.lzh [specific files]
  - verbose list
  lha lv archive_file.lzh
  - print content of archived files
  lha p archive_file.lzh
  - print content of archived files without header string
  lha p -q0 archive_file.lzh

* Test archive
  - test
  lha t archive_file.lzh

* Other
  - version
  lha --version
  - help
  lha --help


