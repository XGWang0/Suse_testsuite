use CGI qw/:standard :html3/;

print header(-type=>'text/html');
print b("done");
