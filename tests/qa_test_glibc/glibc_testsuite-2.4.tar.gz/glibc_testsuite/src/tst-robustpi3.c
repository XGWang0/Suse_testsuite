#define ENABLE_PI 1
#include "tst-robust3.c"
