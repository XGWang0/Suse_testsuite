#define ENABLE_PI 1
#include "tst-mutex8.c"
