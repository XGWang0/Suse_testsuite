#include <stdio.h>


int
main (void)
{
  putc ('1', stderr);
  putc ('2', stderr);

  return 0;
}
