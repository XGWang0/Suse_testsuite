/* Copyright (C) 2005 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, write to the Free
   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307 USA.  */

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>

#define THREADS 10
#define TOTAL 100

pthread_t all_threads[THREADS];

void *
tf (void *arg)
{
  struct timespec delay;
  pthread_detach (pthread_self ());
  delay.tv_sec = 0;
  delay.tv_nsec = 1000 * 1000 * 30;
  nanosleep (&delay, NULL);
  pthread_exit (0);
  return arg;
}

int
do_test (void)
{
  struct timespec delay;
  int i, total = 0;

  delay.tv_sec = 0;
  delay.tv_nsec = 1000 * 1000 * 50;

  do
    {
      for (i = 0; i < THREADS; i++)
	if (total == 0 || pthread_kill (all_threads[i], 0) == ESRCH)
	  pthread_create (&all_threads[i], NULL, tf, NULL);
      total += i;
      nanosleep (&delay, NULL);
    }
  while (total < TOTAL);

  return 0;
}

#define TEST_FUNCTION do_test ()
#define TIMEOUT 6
#include <test-skeleton.c>
