#define TYPE PTHREAD_MUTEX_ADAPTIVE_NP
#include "tst-mutex5.c"
