#define USE_COND_SIGNAL 1
#include "tst-cond12.c"
