#define WAIT_IN_CHILD 1
#include "tst-join5.c"
