package autotest.afe;

class SiteClassFactory extends ClassFactory {
}
