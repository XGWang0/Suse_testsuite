package autotest.common;

public class SiteCommonClassFactory extends CommonClassFactory {
}
