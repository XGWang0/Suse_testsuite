package autotest.common;

public interface SimpleCallback {
    public void doCallback(Object source);
}
