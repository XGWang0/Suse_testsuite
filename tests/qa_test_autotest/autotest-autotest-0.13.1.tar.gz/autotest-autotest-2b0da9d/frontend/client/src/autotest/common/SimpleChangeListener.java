package autotest.common;

public interface SimpleChangeListener {
    public void onChange(Object source);
}
