from autotest_lib.client.virt import virt_test

class libvirt(virt_test.virt_test):
    """
    Suite of libvirt virtualization functional tests.

    @copyright: Red Hat 2011
    """
    pass
