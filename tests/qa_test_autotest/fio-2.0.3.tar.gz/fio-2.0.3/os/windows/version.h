#include "../../fio_version.h"

#define FIO_VERSION_MAJOR FIO_MAJOR
#define FIO_VERSION_MINOR FIO_MINOR
#define FIO_VERSION_BUILD FIO_PATCH
#define FIO_VERSION_STRING "2.0.3"
