#ifndef FIO_VERSION_H
#define FIO_VERSION_H

#define FIO_MAJOR	2
#define FIO_MINOR	0
#define FIO_PATCH	3

#endif
