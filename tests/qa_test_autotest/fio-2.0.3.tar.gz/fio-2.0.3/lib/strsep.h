#ifndef FIO_LIB_H
#define FIO_LIB_H

char *strsep(char **, const char *);

#endif
